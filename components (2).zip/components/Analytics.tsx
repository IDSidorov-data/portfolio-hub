'use client';
import { useEffect } from 'react';

export default function Analytics() {
  useEffect(() => {
    // page_view можно слать тут или доверить GA4 автособытию
  }, []);
  return null;
}